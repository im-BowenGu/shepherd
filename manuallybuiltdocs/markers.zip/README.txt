RoboCon Oxfordshire 2027 - Quidditch AprilTag markers

All markers use the AprilTag 36h11 family and are on A4 PDF pages.
Print at 100% / actual size; do not use "fit to page".

Quaffles: IDs 0 Red, 1 Yellow, 2 Green, 3 Blue (100 x 100 mm)
Snitch: ID 4 Gold (100 x 100 mm)
Arena Walls: 100-102 and 121-123 Red, 103-108 Yellow,
             109-114 Green, 115-120 Blue (200 x 200 mm)
Wall markers should be mounted 50 mm off the floor.
